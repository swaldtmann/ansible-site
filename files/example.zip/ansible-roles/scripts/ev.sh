export EDITOR=nano
ansible-vault edit inventories/test/group_vars/all/vault.yml

