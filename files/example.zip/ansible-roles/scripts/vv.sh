export EDITOR=nano
ansible-vault view inventories/test/group_vars/all/vault.yml

